package br.org.fundatec.exception;

public class AplicarException extends Exception {
	
	public AplicarException(String mensagem) {
		super(mensagem);
	}

}
