package br.org.fundatec.controller;

public class EscolaController {

}
