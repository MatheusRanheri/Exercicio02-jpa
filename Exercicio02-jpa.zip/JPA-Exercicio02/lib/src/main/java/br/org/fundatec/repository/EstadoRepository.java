package br.org.fundatec.repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.org.fundatec.model.Cidade;
import br.org.fundatec.model.Estado;

public class EstadoRepository {
	
	private EntityManager em;
	
	public EstadoRepository() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpa02");
		em = factory.createEntityManager();
		
	}	
		public void inserir(Estado estado) {
			this.em.getTransaction().begin();
			this.em.merge(estado);
			this.em.getTransaction().commit();
		}
		
		public Estado buscar(Integer id) {
			return this.em.find(Estado.class, id);
		}
		
		public void atualixar(Estado estado) {
			this.em.getTransaction().begin();
			this.em.merge(estado);
			this.em.getTransaction().commit();
		}
		
		public void remove(Estado estado) {
			this.em.getTransaction().begin();
			this.em.remove(estado);
			this.em.getTransaction().commit();
		}

}
