package br.org.fundatec.view;

import br.org.fundatec.controller.EscolaController;
import br.org.fundatec.exception.AplicarException;
import br.org.fundatec.util.Tecladoutil;

public class Sistema {
	
	private static EscolaController controller = new EscolaController();
	private static Boolean sair = false;
	
	public static void main(String[] args) {
		while(!sair) {
			menu();
			int opcao = Tecladoutil.lerInteiro("Informe uma opcao");
			executaAcao(opcao);
		}
	}
	
	private static void executaAcao(int opcao) {
		try{
			switch(opcao) {
			case 1:
				System.out.println("Cidade Inserida e UF");
				break;
				
			case 2:
				System.out.println("Cidade com o nome aproximdo");
				break;
				
			case 3:
				System.out.println("UFs listdos");
				break;
				
			case 4:
				System.out.println("Cidades Listadas");
				break;
				
			case 5:
				System.out.println("Total de cidade por estado");
				break;
				
			case 6:
				sair = true;
				break;
				
			default:
				System.out.println("Opção invalida");
				break;
			}
		}catch(AplicarException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void inserirCidadeUf() throws AplicarException {
		
	}

}
