package br.org.fundatec.model;

import java.util.Calendar;
import java.util.Objects;

import javax.persistence.*;

@Entity
@Table(name="estado")
public class Estado {
	
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE , generator="cidade_generator")
	@TableGenerator(name="Cidade_Generator",
		 table="Chave",
		 pkColumnName="id",
		 valueColumnName="valor",
		 allocationSize=1)
	
	@Column(name="Sigla")
	private String sigla;
	
	@Column(name="nome")
	private String nome;
	
	@Column(name="data_Registro")
	private Calendar data_Registro;
	
	public Estado() {
		
	}
//	
//	public Estado(String sigla, String nome, String data_Registro) {
//	this(null, sigla, nome, data_Registro);
//
//	}
	
	public Estado(String sigla, String nome, Calendar data_Registro) {
		this.data_Registro=data_Registro;
		this.nome=nome;
		this.sigla=sigla;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Calendar getData_Registro() {
		return data_Registro;
	}

	public void setData_Registro(Calendar data_Registro) {
		this.data_Registro = data_Registro;
	}

	@Override
	public int hashCode() {
		return Objects.hash(data_Registro, nome, sigla);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Estado other = (Estado) obj;
		return Objects.equals(data_Registro, other.data_Registro) && Objects.equals(nome, other.nome)
				&& Objects.equals(sigla, other.sigla);
	}

	@Override
	public String toString() {
		return "Estado [sigla=" + sigla + ", nome=" + nome + ", data_Registro=" + data_Registro + "]";
	}
	
	
}
