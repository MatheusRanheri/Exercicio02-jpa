package br.org.fundatec.repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.org.fundatec.model.Cidade;

public class CidadeRepository {
	
	private EntityManager em;
	
	public CidadeRepository() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpa02");
		em = factory.createEntityManager();
		
	}	
		public void inserir(Cidade cidade) {
			this.em.getTransaction().begin();
			this.em.merge(cidade);
			this.em.getTransaction().commit();
		}
		
		public Cidade buscar(Integer id) {
			return this.em.find(Cidade.class, id);
		}
		
		public void atualixar(Cidade cidade) {
			this.em.getTransaction().begin();
			this.em.merge(cidade);
			this.em.getTransaction().commit();
		}
		
		public void remove(Cidade cidade) {
			this.em.getTransaction().begin();
			this.em.remove(cidade);
			this.em.getTransaction().commit();
		}

}
