package br.org.fundatec.model;

import java.util.Calendar;
import java.util.Objects;

import javax.persistence.*;

@Entity
@Table(name = "cidade")
public class Cidade {
	
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE , generator="cidade_generator")
	@TableGenerator(name="Cidade_Generator",
		 table="Chave",
		 pkColumnName="id",
		 valueColumnName="valor",
		 allocationSize=1)
	
	@Column(name="id")
	private Integer id;
	
	@Column(name="id_Estado")
	private Integer id_Estado;
	
	@Column(name="nome")
	private String nome;
	
	@Column(name="data_Registro")
	private Calendar data_Registro;
	
	public Cidade() {
		
	}
	
//	public Cidade(String nome, String data_Registro) {
//		this(null, nome, data_Registro);
//	}
	
	public Cidade(Integer id, Integer id_Estado, String nome, Calendar data_Registro) {
		this.id=id;
		this.id_Estado=id_Estado;
		this.nome=nome;
		this.data_Registro=data_Registro;
		 
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getId_Estado() {
		return id_Estado;
	}

	public void setId_Estado(Integer id_Estado) {
		this.id_Estado = id_Estado;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Calendar getData_Registro() {
		return data_Registro;
	}

	public void setData_Registro(Calendar data_Registro) {
		this.data_Registro = data_Registro;
	}

	@Override
	public int hashCode() {
		return Objects.hash(data_Registro, id, id_Estado, nome);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cidade other = (Cidade) obj;
		return Objects.equals(data_Registro, other.data_Registro) && Objects.equals(id, other.id)
				&& Objects.equals(id_Estado, other.id_Estado) && Objects.equals(nome, other.nome);
	}

	@Override
	public String toString() {
		return "Cidade [id=" + id + ", id_Estado=" + id_Estado + ", nome=" + nome + ", data_Registro=" + data_Registro
				+ "]";
	}
	
	
}
